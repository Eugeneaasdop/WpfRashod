﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfRashod.Classes;

namespace WpfRashod.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddCat.xaml
    /// </summary>
    public partial class PageAddCat : Page
    {
        private CostCategory _currentCategor = new CostCategory();
        public PageAddCat(CostCategory selectedcategory)
        {
            InitializeComponent();
            if (selectedcategory != null)
            {
                _currentCategor = selectedcategory;
                Titletxt.Text = "Редактирование категории";
                btnAddras.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentCategor;
        }

        private void btnAddras_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentCategor.Name)) error.AppendLine("Укажите название");
            if (AccountingEntities.GetContext().CostCategory.Where(x => x.Name == Txtcoment.Text).Count() > 0)
            {
                MessageBox.Show("Такая категория уже есть");
                return;
            }
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentCategor.Id_category == 0)
            {
                AccountingEntities.GetContext().CostCategory.Add(_currentCategor);
                try
                {
                    AccountingEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageCategor());
                    MessageBox.Show("Новая категория успешно добавлена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    AccountingEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageCategor());
                    MessageBox.Show("Категория успешно изменена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageCategor());
        }
    }
}
