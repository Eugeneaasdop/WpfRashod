﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfRashod.Classes;

namespace WpfRashod.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageCategor.xaml
    /// </summary>
    public partial class PageCategor : Page
    {
        public PageCategor()
        {
            InitializeComponent();
            DtgSQL.ItemsSource = AccountingEntities.GetContext().CostCategory.ToList();
            System.Int32 customerCount = AccountingEntities.GetContext().CostCategory.Count();
            Txtname.Text = customerCount.ToString();
        }

        private void Findcat_TextChanged(object sender, TextChangedEventArgs e)
        {
            DtgSQL.ItemsSource = AccountingEntities.GetContext().CostCategory.Where(x => x.Name.ToLower().Contains(Findcat.Text.ToLower())).ToList();
            int count = AccountingEntities.GetContext().CostCategory.Where(x => x.Name.ToLower().Contains(Findcat.Text.ToLower())).ToList().Count();
            Txtname.Text = count.ToString();
        }

        private void Btnadd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddCat(null));
        }

        private void PCategor_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageExpenses());
        }

        private void BTNedit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddCat((CostCategory)DtgSQL.SelectedItem));
        }

        private void Delette_Click(object sender, RoutedEventArgs e)
        {
            var AftoForRemoving = DtgSQL.SelectedItems.Cast<CostCategory>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {AftoForRemoving.Count()} записи?", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    AccountingEntities.GetContext().CostCategory.RemoveRange(AftoForRemoving);
                    AccountingEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQL.ItemsSource = AccountingEntities.GetContext().CostCategory.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            int count = AccountingEntities.GetContext().CostCategory.Count();
            Txtname.Text = count.ToString();
        }
    }
}
