﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using WpfRashod.Classes;

namespace WpfRashod.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddExpenses.xaml
    /// </summary>
    public partial class PageAddExpenses : Page
    {
        private Expenses _currentExpenses = new Expenses();
        public PageAddExpenses(Expenses selectedexpenses)
        {
            InitializeComponent();

            CMBCategor.ItemsSource = AccountingEntities.GetContext().CostCategory.ToList();
            CMBCategor.SelectedValuePath = "Id_category";
            CMBCategor.DisplayMemberPath = "Name";

            if (selectedexpenses != null)
            {
                _currentExpenses = selectedexpenses;
                Titletxt.Text = "Редактирование расходов";
                btnAddras.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentExpenses;
        }

        private void btnAddras_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentExpenses.Comment)) error.AppendLine("Укажите коментарий");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentExpenses.Price))) error.AppendLine("Укажите цену");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentExpenses.Date))) error.AppendLine("Укажите дату");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentExpenses.Id_category))) error.AppendLine("Укажите категорию");
            if (AccountingEntities.GetContext().Expenses.Where(x => x.Comment == Txtcoment.Text && x.Price.ToString() == Txtprice.Text && x.CostCategory.Name.ToString() == CMBCategor.Text).Count() > 0)
            {
                MessageBox.Show("Такой расход уже есть");
                return;
            }
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentExpenses.Id_expenses == 0)
            {
                AccountingEntities.GetContext().Expenses.Add(_currentExpenses);
                try
                {
                    AccountingEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageExpenses());
                    MessageBox.Show("Новый расход успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    AccountingEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageExpenses());
                    MessageBox.Show("Расход успешно изменен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageExpenses());
        }
    }
}
