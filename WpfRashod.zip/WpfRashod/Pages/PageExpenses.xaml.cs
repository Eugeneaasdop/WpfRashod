﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfRashod.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace WpfRashod.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageExpenses.xaml
    /// </summary>
    public partial class PageExpenses : Page
    {
        public PageExpenses()
        {
            InitializeComponent();
            DtgSQL.ItemsSource = AccountingEntities.GetContext().Expenses.ToList();
            var listcat = AccountingEntities.GetContext().CostCategory.Select(x => x.Name).Distinct().ToList();
            CMBFilterForm.Items.Add("Все категории");
            foreach (string Categori in listcat)
            {
                CMBFilterForm.Items.Add(Categori);
            }
            System.Int32 customerCount = AccountingEntities.GetContext().Expenses.Count();
            Txtname.Text = customerCount.ToString();
        }

        private void PCategor_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageCategor());
        }

        private void Delette_Click(object sender, RoutedEventArgs e)
        {
            var AftoForRemoving = DtgSQL.SelectedItems.Cast<Expenses>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {AftoForRemoving.Count()} записи?", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    AccountingEntities.GetContext().Expenses.RemoveRange(AftoForRemoving);
                    AccountingEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQL.ItemsSource = AccountingEntities.GetContext().Expenses.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            int count = AccountingEntities.GetContext().Expenses.Count();
            Txtname.Text = count.ToString();
        }

        private void BTNedit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddExpenses((Expenses)DtgSQL.SelectedItem));
        }

        private void BtnExcel_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Shablon.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[7, 1] = "Статистика";
            ws.Cells[8, 1] = "Дата";
            DateTime thisDay = DateTime.Today;
            ws.Cells[8, 2] = thisDay.ToShortDateString();
            int indexRows = 9;
            //ячейка
            ws.Cells[1][indexRows] = "Дата";
            ws.Cells[2][indexRows] = "Категория";
            ws.Cells[3][indexRows] = "Цена";
            var printItems = DtgSQL.Items;
            //цикл по данным из списка для печати
            foreach (Expenses item in printItems)
            {
                ws.Cells[1][indexRows + 1] = item.Date;
                ws.Cells[2][indexRows + 1] = item.CostCategory.Name;
                ws.Cells[3][indexRows + 1] = item.Price;
                indexRows++;
            }
            int ch = (int)AccountingEntities.GetContext().Expenses.Sum(x => x.Price);
            ws.Cells[indexRows + 2, 1] = "Сумма:";
            ws.Cells[indexRows + 2, 2] = ch.ToString();
            excelApp.Visible = true;
        }

        private void Btnadd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddExpenses(null));
        }

        private void CMBFilterForm_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string form = CMBFilterForm.SelectedValue.ToString();
            if (form != "Все категории")
            {
                int cod = AccountingEntities.GetContext().CostCategory.First(x => x.Name == form).Id_category;
                DtgSQL.ItemsSource = AccountingEntities.GetContext().Expenses.Where(x => x.Id_category == cod).ToList();
                int count = AccountingEntities.GetContext().Expenses.Where(x => x.Id_category == cod).Count();
                Txtname.Text = count.ToString();
            }
            else
            {
                DtgSQL.ItemsSource = AccountingEntities.GetContext().Expenses.ToList();
                int count1 = AccountingEntities.GetContext().Expenses.Count();
                Txtname.Text = count1.ToString();
            }
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DtgSQL.ItemsSource = AccountingEntities.GetContext().Expenses.OrderBy(x => x.Price).ToList();
            int count = AccountingEntities.GetContext().Expenses.OrderBy(x => x.Price).Count();
            Txtname.Text = count.ToString();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DtgSQL.ItemsSource = AccountingEntities.GetContext().Expenses.OrderByDescending(x => x.Price).ToList();
            int count = AccountingEntities.GetContext().Expenses.OrderByDescending(x => x.Price).Count();
            Txtname.Text = count.ToString();
        }

        private void Findcomen_TextChanged(object sender, TextChangedEventArgs e)
        {
            DtgSQL.ItemsSource = AccountingEntities.GetContext().Expenses.Where(x => x.Comment.ToLower().Contains(Findcomen.Text.ToLower())).ToList();
            int count = AccountingEntities.GetContext().Expenses.Where(x => x.Comment.ToLower().Contains(Findcomen.Text.ToLower())).ToList().Count();
            Txtname.Text = count.ToString();
        }
    }
}
